/* PROGRAM TO PRINT NUMBERS FROM 1 to N*/
#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	printf("%d\t",i);
	return 0;
}
