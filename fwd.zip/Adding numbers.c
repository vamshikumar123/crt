#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter Values of a and b\n");
	scanf("%d%d",&a,&b);
	c=a+b;
	printf("The SUM IS %d",c);
	return 0;
}
